
var isMobile;

function fsSlider() {
	//Menu 1
	$("#productssslide_makeup_menu_slide").owlCarousel({
		items: 3,
		autoplay: false,
		autoplayTimeout: 5000,
		autoplayHoverPause: true,
		loop: false,
		navRewind: true,
		margin: 40,
		dots: false,
		nav: false,
		navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
		responsive: {
		0: {margin: 15,items: 2},
		479: {items: 2},
		768: {items: 3},
		991: {items: 3},
		1024: {items: 3}
		},
		lazyLoad: true
	});
 	//Menu 2
 	$("#productssslide_5").owlCarousel({
		items: 3,
		autoplay: false,
		autoplayTimeout: 5000,
		autoplayHoverPause: true,
		loop: false,
		navRewind: true,
		margin: 40,
		dots: false,
		nav: false,
		navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
		responsive: {
		0: {margin: 15,items: 2},
		479: {items: 2},
		768: {items: 3},
		991: {items: 3},
		1024: {items: 3}
		},
		lazyLoad: true
	});

	//Menu 3
	$("#productssslide_accessories_menu_slide").owlCarousel({
		items: 3,
		autoplay: false,
		autoplayTimeout: 5000,
		autoplayHoverPause: true,
		loop: false,
		navRewind: true,
		margin: 40,
		dots: false,
		nav: false,
		navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
		responsive: {
		0: {margin: 15,items: 2},
		479: {items: 2},
		768: {items: 3},
		991: {items: 3},
		1024: {items: 3}
		},
		lazyLoad: true
	});

	//Home Slider
	var banner_owl = $("#home-slider");
	banner_owl.owlCarousel({
		items: 1,
		autoplay: true,
		autoplayTimeout: 8000,
		autoplayHoverPause: true,
		loop: true,
		dots: true,
		nav: true,
		navRewind: true,
		animateIn: 'fadeIn',
		animateOut: 'fadeOut',
		navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
		lazyLoad: true
	});
	
}

// Init Map
function initialize(Lat,Lng) {
	var latLng = new google.maps.LatLng(Lat,Lng);
		var mapOptions = {
		center:latLng,
		zoom: 15,
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		disableDefaultUI: true
		};
		var map = new google.maps.Map(document.getElementById("map_location"), mapOptions);

		var marker = new google.maps.Marker({
		position: latLng,
		map: map
	});
}

// Store Progress
function findStore(formid) {
	$('.loading-ajax').show();
	var action =  $('#'+formid).attr('action');
	jQuery.ajax({
		url :action,
		type: "POST",
		data : $('#'+formid).serializeArray(),
		dataType: 'json',
		success: function(data){
			$('#list_store').html('');
			$('.loading-ajax').hide();
			$('#list_store').html(data.list_locator);

			var Lat = $('.header-block-store-location #list_store .item-store.first').attr('attr-lat');
			var Lng = $('.header-block-store-location #list_store .item-store.first').attr('attr-lng');

			if(Lat == 0){
			return;
			}

			initialize(Lat,Lng);

		},
		error: function ()
		{
			$('.loading-ajax').hide();
		}
	});
}

function getCurrentAroundLocation() {
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(showPosition);
	} else {
		alert('Not matches were found');
	}
}

function showPosition(position) {
	$('.loading-ajax').show();
	var lat = position.coords.latitude;
	var lon = position.coords.longitude;

	var action =  'https://www.shuuemura.com.sg/shu_location/locator/arroundposition/';

	jQuery.ajax({
		url :action,
		type: "POST",
		data :  {lat : lat, lon : lon, arround:true},
		dataType: 'json',
		success: function(data) {
			$('#list_store').html('');
			$('.loading-ajax').hide();
			$('#list_store').html(data.list_locator);
			initialize(lat,lon);
		},
		error: function () {
			$('.loading-ajax').hide();
		}
	});
}

function openArtist() {

	if($('.learn-artist-popup').length) {
		setTimeout(function(){
			$('body').addClass('_has-modal');
			$('.learn-artist-popup').addClass('_show');
		},1000);
	}

}


function fsEvents() {
	
	// Open menu
	$('.nav-toggle').on('click', function(){
		if($('html').hasClass('nav-open')) {
			$('html').removeClass('nav-open nav-before-open');
		}else {
			$('html').addClass('nav-before-open nav-open');
		}
	});
	
	// Open Submenu Level0
	$('.ui-menu-item > .open-children-toggle').on('click', function(){
		$(this).parent().find('.level0').addClass('opened');
	});

	// Open Submenu Level1
	$('.level0.submenu .open-children-toggle').on('click', function(){
		$(this).parent().find('.subchildmenu').addClass('opened');
	});

	// Close current Submenu
	$('.back-menu').on('click', function(){
		$(this).parent().removeClass('opened');
	});

	// Initmap when click any Store
	$('.header-store-right').on('click', '.item-store', function(){
		var lat = $(this).attr('attr-lat');
		var lng = $(this).attr('attr-lng');
		initialize(lat, lng);
		console.log('Lat:',lat);
		console.log('Lng:',lng);
	});

	// Search Store by Input
	$('#address_header').keyup(function(e){
		$('#header_form_find_store').submit(false);
		if(e.keyCode == 13) {
			var formid = 'header_form_find_store';
			findStore(formid);
		}
	});

	//Search Stores
	setTimeout(function(){
		$('.header-block-store-location #list_store .item-store.first').trigger('click');
	}, 3000);

	// Search Toggle
	$('.header-search').on('click', '.dropdown-toggle', function(){
		if($(this).hasClass('active-search')) {
			$(this).removeClass('active-search');
			$('.search-switcher .dropdown-switcher').slideUp();
		}else {
			$(this).addClass('active-search');
			$('.search-switcher .dropdown-switcher').slideDown();
			$('#search').focus();
		}
	});

	// Close Artist Popup
	$('.close-popup').on('click', function(e){
		e.preventDefault();
		$('.learn-artist-popup').removeClass('_show');
		$('body').removeClass('_has-modal');
	});

	 //Close any Tooltip when click out
	 $(document).on('click touchstart', function (event) {
        //Close select
        if ($(".header-content").has(event.target).length == 0 && !$(".header-content").is(event.target)) {
			$('.search-switcher .dropdown-switcher').slideUp();
			$('.header-search .dropdown-toggle').removeClass('active-search');
        }
    });

}

function ImgLazyLoad() {
	var mainImage = $('img.main-img');
    if( $(window).width() < 750 ) {
		mainImage.each(function () {
			$(this).attr("src",$(this).data('mobile'));
		});
	}
	else {
		mainImage.each(function () {
			$(this).attr("src",$(this).data('desktop'));
		});
	}
	
}

// Func Scroll
function onScroll() {

    // setTimeout(function () {

    //     scrollPos = $(window).scrollTop();

    //     if (isCroll) { // Anythings which you want progress after allow scroll
    //         if (scrollPos >= window.innerHeight / 2) {
    //             $('.fs-top').addClass('fs-show-top');
    //         } else {
    //             $('.fs-top').removeClass('fs-show-top');
    //         }
    //     }

    //     [].slice.call(document.querySelectorAll('.fs-section')).forEach(function (elm) {
    //         if (elm.getBoundingClientRect().top <= $(window).height() - delTop) {
    //             elm.classList.add('fs-ani');
    //         }
    //     });

    //     ImgLazyLoad();
    // }, 0);  // Process for Input Delay

}

// Func Resize
function Resize() {

	// Need detect not mobile when resize because in mobile scrolling call resize
	if (!isMobile) {
		ImgLazyLoad();
	}

}


// Func Rotate
function Rotate() {
    ImgLazyLoad();
}

// Set Scroll for Page
$(window).on('scroll', onScroll);

// Page Rezize
$(window).on('resize', Resize);

// Page Rotate
$(window).on('orientationchange', Rotate);


$(document).ready(function() {
	ImgLazyLoad();
	fsSlider();
	fsEvents();
	openArtist();

});