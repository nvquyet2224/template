


var planeSymbol = null;

var animLoop = false,
	animIndex = 0,
	planePath = false,
	trailPath = false;

var mapId = 'map';
var map;

var drawing = true;

function animate(startPoint, endPoint, aniTimer) {
	console.log(startPoint, endPoint);

	//startPoint = places[startPoint],
	//endPoint = places[endPoint];

	// Convert the points arrays into Lat / Lng objects
	var sP = new google.maps.LatLng(startPoint[0], startPoint[1]);
	var eP = new google.maps.LatLng(endPoint[0], endPoint[1]);

	// Create a polyline for the planes path

	planePath = new google.maps.Polyline({
		path: [sP, eP],
		strokeColor: '#0f0',
		strokeWeight: 0,
		icons: [{
			icon: planeSymbol,
			offset: '0%'
		}],
		map: map,
		geodesic: true
	});

	trailPath = new google.maps.Polyline({
		path: [sP, sP],
		strokeColor: '#2eacd0',
		strokeWeight: 2,
		map: map,
		geodesic: true
	});

	// Start the animation loop
	animLoop = window.requestAnimationFrame(function () {
		tick(sP, eP, aniTimer);
	});

}

/*
function tick(startPoint, endPoint, aniTimer) {
	//aniTimer += 0.5;

	// Draw trail
	//var nextPoint = google.maps.geometry.spherical.interpolate(startPoint, endPoint, aniTimer / 10);
	//trailPath.setPath([startPoint, nextPoint]);

	// Move the plane
	//planePath.icons[0].offset = Math.min(aniTimer, 10) + '%';
	//planePath.setPath(planePath.getPath());

	// Ensure the plane is in the center of the screen
	//map.panTo(nextPoint);

	// if (aniTimer < 10) {
	// 	tick(startPoint, endPoint, aniTimer);
	// }

	// We've reached the end, clear animLoop
	if (aniTimer >= 100) {
		window.cancelAnimationFrame(animLoop);
		aniTimer = 0;
		drawing = true;
	} else {
		animLoop = window.requestAnimationFrame(function () {
			tick(startPoint, endPoint, aniTimer);
		});
	}

}*/


function tick(startPoint, endPoint, poly, aniTimer) {
	aniTimer += 0.5;
	
	// Draw trail
	var startPoint1 = new google.maps.LatLng(startPoint[0], startPoint[1]);
	var endPoint1 = new google.maps.LatLng(endPoint[0], endPoint[1]);

	//console.log(startPoint);
	//console.log(endPoint);

	var nextPoint = google.maps.geometry.spherical.interpolate(startPoint1, endPoint1, aniTimer / 100);

	var path = [startPoint1, nextPoint];
	
	poly.setPath(path);

	//var path = [{ lat: latReg, lng: lngReg }, { lat: latDes, lng: lngDes }];
	//poly.setPath(path);

	// Move the plane
	//planePath.icons[0].offset = Math.min(aniTimer, 100) + '%';
	//planePath.setPath(planePath.getPath());

	// We've reached the end, clear animLoop
	// if (aniTimer >= 100) {
	// 	window.cancelAnimationFrame(animLoop);
	// 	aniTimer = 0;
	// } else {
	// 	animLoop = window.requestAnimationFrame(function () {
	// 		tick(startPoint, endPoint, poly, aniTimer);
	// 	});
	// }

}


function initMap() {

	console.log('initMap');

	planeSymbol = {
		path: 'M22.1,15.1c0,0-1.4-1.3-3-3l0-1.9c0-0.2-0.2-0.4-0.4-0.4l-0.5,0c-0.2,0-0.4,0.2-0.4,0.4l0,0.7c-0.5-0.5-1.1-1.1-1.6-1.6l0-1.5c0-0.2-0.2-0.4-0.4-0.4l-0.4,0c-0.2,0-0.4,0.2-0.4,0.4l0,0.3c-1-0.9-1.8-1.7-2-1.9c-0.3-0.2-0.5-0.3-0.6-0.4l-0.3-3.8c0-0.2-0.3-0.9-1.1-0.9c-0.8,0-1.1,0.8-1.1,0.9L9.7,6.1C9.5,6.2,9.4,6.3,9.2,6.4c-0.3,0.2-1,0.9-2,1.9l0-0.3c0-0.2-0.2-0.4-0.4-0.4l-0.4,0C6.2,7.5,6,7.7,6,7.9l0,1.5c-0.5,0.5-1.1,1-1.6,1.6l0-0.7c0-0.2-0.2-0.4-0.4-0.4l-0.5,0c-0.2,0-0.4,0.2-0.4,0.4l0,1.9c-1.7,1.6-3,3-3,3c0,0.1,0,1.2,0,1.2s0.2,0.4,0.5,0.4s4.6-4.4,7.8-4.7c0.7,0,1.1-0.1,1.4,0l0.3,5.8l-2.5,2.2c0,0-0.2,1.1,0,1.1c0.2,0.1,0.6,0,0.7-0.2c0.1-0.2,0.6-0.2,1.4-0.4c0.2,0,0.4-0.1,0.5-0.2c0.1,0.2,0.2,0.4,0.7,0.4c0.5,0,0.6-0.2,0.7-0.4c0.1,0.1,0.3,0.1,0.5,0.2c0.8,0.2,1.3,0.2,1.4,0.4c0.1,0.2,0.6,0.3,0.7,0.2c0.2-0.1,0-1.1,0-1.1l-2.5-2.2l0.3-5.7c0.3-0.3,0.7-0.1,1.6-0.1c3.3,0.3,7.6,4.7,7.8,4.7c0.3,0,0.5-0.4,0.5-0.4S22,15.3,22.1,15.1z',
		fillColor: '#000',
		fillOpacity: 1.5,
		scale: 0.8,
		anchor: new google.maps.Point(11, 11),
		strokeWeight: 0
	};

	map = new google.maps.Map(document.getElementById('map'), {
		center: { lat: 36.544138247541014, lng: -93.06138603986801 },
		zoom: 3,
		styles: [
			{
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#31363c"
					}
				]
			},
			{
				"elementType": "labels",
				"stylers": [
					{
						"visibility": "off"
					}
				]
			},
			{
				"elementType": "labels.icon",
				"stylers": [
					{
						"visibility": "off"
					}
				]
			},
			{
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#757575"
					}
				]
			},
			{
				"elementType": "labels.text.stroke",
				"stylers": [
					{
						"color": "#212121"
					}
				]
			},
			{
				"featureType": "administrative",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#757575"
					}
				]
			},
			{
				"featureType": "administrative.country",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#9e9e9e"
					}
				]
			},
			{
				"featureType": "administrative.land_parcel",
				"stylers": [
					{
						"visibility": "off"
					}
				]
			},
			{
				"featureType": "administrative.locality",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#bdbdbd"
					}
				]
			},
			{
				"featureType": "administrative.neighborhood",
				"stylers": [
					{
						"visibility": "off"
					}
				]
			},
			{
				"featureType": "poi",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#757575"
					}
				]
			},
			{
				"featureType": "poi.park",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#181818"
					}
				]
			},
			{
				"featureType": "poi.park",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#616161"
					}
				]
			},
			{
				"featureType": "poi.park",
				"elementType": "labels.text.stroke",
				"stylers": [
					{
						"color": "#1b1b1b"
					}
				]
			},
			{
				"featureType": "poi.sports_complex",
				"elementType": "geometry.fill",
				"stylers": [
					{
						"color": "#f00f0f"
					},
					{
						"saturation": -30
					},
					{
						"visibility": "on"
					}
				]
			},
			{
				"featureType": "road",
				"stylers": [
					{
						"visibility": "off"
					}
				]
			},
			{
				"featureType": "road",
				"elementType": "geometry.fill",
				"stylers": [
					{
						"color": "#2c2c2c"
					}
				]
			},
			{
				"featureType": "road",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#8a8a8a"
					}
				]
			},
			{
				"featureType": "road.arterial",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#373737"
					}
				]
			},
			{
				"featureType": "road.highway",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#3c3c3c"
					}
				]
			},
			{
				"featureType": "road.highway.controlled_access",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#4e4e4e"
					}
				]
			},
			{
				"featureType": "road.local",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#616161"
					}
				]
			},
			{
				"featureType": "transit",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#757575"
					}
				]
			},
			{
				"featureType": "transit.station.airport",
				"elementType": "geometry.fill",
				"stylers": [
					{
						"color": "#ffeb3b"
					},
					{
						"visibility": "on"
					}
				]
			},
			{
				"featureType": "water",
				"elementType": "geometry",
				"stylers": [
					{
						"color": "#000000"
					}
				]
			},
			{
				"featureType": "water",
				"elementType": "labels.text.fill",
				"stylers": [
					{
						"color": "#3d3d3d"
					}
				]
			}
		]
	});


	createMarker();

}

function centerMap(lat, long) {
	var center = new google.maps.LatLng(lat, long);
	map.setCenter(center);
}


var markers = [];

function checkMarker(name) {
	var newMarker = true;
	for (var i = 0; i < markers.length; i++) {
		if (markers[i].name == name) {
			newMarker = false;
			break;
		}
	}
	return newMarker;
}

// 1 thành phố có lat, long là điểm bắt đầu
//

function createMarker() {

	var count = 0;
	var infowindow = new google.maps.InfoWindow();
	$.getJSON("jsons/td.json", function (result) {

		$.each(result, function (i, field) {

			// Get Regions in by_source
			for (const property in field.by_source) {

				// property is Region name
				var latReg = field.by_source[property].lat;
				var lngReg = field.by_source[property].long;
				var logoReg = 'images/marker.png';

				if (latReg && lngReg) {

					// Check Region exited
					if (checkMarker(property)) {

						if (latReg != undefined || lngReg != undefined) {
							//console.log('add region');
							// Add Region marker
							var markerReg = new google.maps.Marker({
								//storeid: locations[i].storeid,
								position: {
									lat: latReg,
									lng: lngReg
								},
								icon: logoReg,
								map: map,
								//animation: google.maps.Animation.DROP,
								info: '<p>' + property + '</p>'
							});

							markerReg.addListener('click', function () {
								//var id = this.id;
								//console.log(id);
								infowindow.setContent(this.info);
								infowindow.open(map, this);
							});
						}

						markers.push({ name: property });

					} else {
						//console.log('This Region exited');
					}

					// Add destinations marker
					for (var i = 0; i < field.by_source[property].destinations.length; i++) {
						//console.log('add destinations');
						var latDes = field.by_source[property].destinations[i].lat;
						var lngDes = field.by_source[property].destinations[i].long;

						if (checkMarker(field.by_source[property].destinations[i].name)) {

							var markerDes = new google.maps.Marker({
								//storeid: locations[i].storeid,
								position: {
									lat: latDes,
									lng: lngDes
								},
								//icon: logoReg,
								map: map,
								//animation: google.maps.Animation.DROP,
								info: '<p>' + field.by_source[property].destinations[i].name + '</p>'
							});

							markerDes.addListener('click', function () {
								//var id = this.id;
								//console.log(id);
								infowindow.setContent(this.info);
								infowindow.open(map, this);
							});
							markers.push({ name: property });
							/*
							var poly = new google.maps.Polyline({
								strokeColor: "#CCCC09",
								strokeOpacity: 1.0,
								strokeWeight: 3,
								geodesic: true,
								map: map,
								// icons: [
								//   {
								//     icon: lineSymbol,
								//     offset: "100%"
								//   }
								// ]
							});

							var path = [markerReg.getPosition(), markerDes.getPosition()];
							poly.setPath(path);*/

						} else {

						}

						if (latReg && lngReg && latDes && lngDes && count == 1) {

							var poly = new google.maps.Polyline({
								path = [{ lat: latReg, lng: lngReg }, { lat: latDes, lng: lngDes }],
								strokeColor: "#CCCC09",
								strokeOpacity: 1.0,
								strokeWeight: 3,
								geodesic: true,
								map: map,
								// icons: [
								//   {
								//     icon: lineSymbol,
								//     offset: "100%"
								//   }
								// ]
							});

							//var path = [{ lat: latReg, lng: lngReg }, { lat: latDes, lng: lngDes }];
							//poly.setPath(path);

							animLoop = window.requestAnimationFrame(function () {
								tick({ lat: latReg, lng: lngReg }, { lat: latDes, lng: lngDes }, poly, 0);
							});
							
						}

					}

				}

			}

			count++;

		});

		/*setTimeout(function () {
			flightAni();
		}, 300);*/

	});

}

function update() {
  /*const path = [marker1.getPosition(), marker2.getPosition()];
  const path1 = [marker1.getPosition(), marker3.getPosition()];
  poly.setPath(path);
  geodesicPoly.setPath(path);
  geodesicPoly1.setPath(path1);  
  animateCircle(poly);
  animateCircle(geodesicPoly);
  animateCircle(geodesicPoly1);*/
}

function animateCircle(line) {
  /*let count = 0;
  window.setInterval(() => {
    count = (count + 1) % 200;
    const icons = line.get("icons");
    icons[0].offset = count / 2 + "%";
    line.set("icons", icons);
  }, 20);*/
}

// Page Ready
(function () {

})();
